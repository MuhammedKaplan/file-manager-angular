import { File } from './file';

describe('File', () => {
  it('should create an instance', () => {
    expect(new File()).toBeTruthy();
  });
});
